import subprocess

subprocess.Popen(["python3", "subscriber_bot.py"])
subprocess.Popen(["python3", "monitor_bot.py"])
